<div class="footer">
    <p class="copyright">&copy; copyright McKodev Links 2017</p>
  </div>
</body>
</html>
